//
//  ContentView.swift
//  calender
//
//  Created by saravana kumar on 16/10/23.
//

import SwiftUI
import CoreData

extension View {
    /// Sets the text color for a navigation bar title.
    /// - Parameter color: Color the title should be
    ///
    /// Supports both regular and large titles.
    @available(iOS 14, *)
    func navigationBarTitleTextColor(_ color: Color) -> some View {
        let uiColor = UIColor(color)
    
        // Set appearance for both normal and large sizes.
        UINavigationBar.appearance().titleTextAttributes = [.foregroundColor: uiColor ]
        UINavigationBar.appearance().largeTitleTextAttributes = [.foregroundColor: uiColor ]
    
        return self
    }
}

struct ContentView: View {
    @State private var date = Date()
    var body: some View
    {
        HStack{
        NavigationView {
                    List {
                        
                            Text("Planning...")
                            .foregroundColor(Color.green)
                            
                        DatePicker(
                                "Start Date",
                                selection: $date,
                                displayedComponents: [.date]
                                
                            )
                        
                            .datePickerStyle(.graphical)
                        NavigationLink(destination: sessionView()){
                            Text("Create Plan").padding(.leading,130).foregroundColor(Color.green)
                                        }
                        
                    }
                    .navigationTitle("Tour Plan")
                    .navigationBarTitleDisplayMode(.automatic)
                    .navigationBarTitleTextColor(Color.gray)
            
}
        
//        NavigationView {
//                    List {
//                        NavigationLink("Open Next View")
//                        {
//                                        sessionView()
//                        }
//                    }
//                    .navigationTitle("Summary")
//                    .navigationBarTitleDisplayMode(.automatic)
//                    .navigationBarTitleTextColor(Color.gray)
//}
        }
    }
    
                           }

