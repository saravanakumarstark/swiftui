//
//  ContentView.swift
//  calender
//
//  Created by saravana kumar on 16/10/23.
//

import SwiftUI
import CoreData



struct sessionView: View {
    @State private var navigateToNextView = false
        
    var body: some View
    {

        HStack{
            List
                    {
                       
                                HStack
                                {
                                    Text("01 October 2023 ")
                                        .font(.system(size: 20))
                                    Spacer()
                                    Button(action: {
                                        print("Info button tapped!")
                                    }) {
                                        Image(systemName: "ellipsis")
                                            .foregroundColor(Color.black)
                                    }
                                    
                                }
                        HStack
                        {
                            Text("Field Work ")
                                .font(.system(size: 20))
                            Spacer()
                            Text("HQ - Shiva Kumar")
                                .font(.system(size: 20))
                            
                        }
                    
                       
                            
                        NavigationLink {
                            // destination view to navigation to
                            addplanView()
                        } label: {
                            Text("Send to Approval").padding(.leading,100)
                                .foregroundColor(.gray)
                        }
                        
                                    }
                            
                        
                    }
                    .navigationTitle("Summary")
                    .navigationBarTitleDisplayMode(.automatic)
                    .navigationBarTitleTextColor(Color.gray)
            

        

        }
    }
    

