//
//  ContentView.swift
//  calender
//
//  Created by saravana kumar on 16/10/23.
//

import SwiftUI
import CoreData



struct addplanView: View {
    @State private var navigateToNextView = false
    @State private var selectedStrength = "Select"
        let strengths = ["Field Work", "Meeting", "Stock"]
    
    @State private var clusterStrength = "Select"
        let strength = ["Cluster 1", "Cluster 2", "Cluster 3"]
    
    @State private var selectedStrength1 = "Select"
        let strengths1 = ["Field Work", "Meeting", "Stock"]
    
    @State private var clusterStrength1 = "Select"
        let strength1 = ["Cluster 1", "Cluster 2", "Cluster 3"]
    var body: some View
{
    
    NavigationView {
        
        Form {
            Section {
                HStack
                {
                    Text("Session 1")
                        .font(.system(size: 20))
                    Spacer()
                    Button(action: {
                        print("Info button tapped!")
                    }) {
                        Image(systemName: "trash")
                            .foregroundColor(Color.red)
                    }
                }
                Text("Work Type")
                    .font(.system(size: 18))
                    .foregroundColor(Color.gray)
                Picker("Select", selection: $selectedStrength) {
                                       ForEach(strengths, id: \.self) {
                                           Text($0)
                                       }}
                Text("Cluster")
                    .font(.system(size: 18))
                    .foregroundColor(Color.gray)
                Picker("Select", selection: $clusterStrength) {
                                       ForEach(strength, id: \.self) {
                                           Text($0)
                                       }}
            }

            Section
            {
                HStack
                {
                    Text("Session 2")
                        .font(.system(size: 20))
                    Spacer()
                    Button(action: {
                        print("Info button tapped!")
                    }) {
                        Image(systemName: "trash")
                            .foregroundColor(Color.red)
                    }
                }
                Text("Work Type")
                    .font(.system(size: 18))
                    .foregroundColor(Color.gray)
                Picker("Select", selection: $selectedStrength1) {
                                       ForEach(strengths1, id: \.self) {
                                           Text($0)
                                       }}
                Text("Cluster")
                    .font(.system(size: 18))
                    .foregroundColor(Color.gray)
                Picker("Select", selection: $clusterStrength1) {
                                       ForEach(strength1, id: \.self) {
                                           Text($0)
                                       }}
            }
            Section
            {
                HStack
                {
                    Button("+ Add Session"){}.foregroundColor(Color.green)
                    
                    Spacer()
                    Button("Save"){}
                    .background(Color.black)
                    .foregroundColor(Color.white)
                    .cornerRadius(8)
                    
                }
            }
        }
        .navigationBarItems(leading:
            HStack {
            

                Text("Add Plan")
                .foregroundColor(Color.gray)
                .fontWeight(.semibold)
                .font(.system(size: 30))

            }, trailing:
                HStack {
                    Button(action: {
                        print("Info button tapped!")
                    }) {
                        Image(systemName: "xmark")
                    }
                    .foregroundColor(Color.gray)
                }
        )
        

    }
    
   
        
}
       

        

        }

//struct TopBar:View
//{
//    var body some View
//    {
//        
//    }
//}
    

